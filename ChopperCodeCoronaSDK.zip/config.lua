-- cpmgen config.lua
application =
{
	content =
	{
		width = 640,
		height = 960,
		scale = "letterbox",
		fps = 60,
		antialias = false,
		xalign = "center",
		yalign = "center"
	}
}